# coding:utf-8

from colorama import Back, Fore, Style

print(Fore.CYAN, 'HelloWorld')
print(Back.RED, 'HelloWorld')
print(Style.RESET_ALL, 'HelloWorld')
