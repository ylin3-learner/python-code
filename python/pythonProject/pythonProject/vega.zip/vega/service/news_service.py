# coding:utf-8

from db.news_dao import NewsDao

class NewsService():
    __news_dao = NewsDao()

    # 查詢待審核新聞列表
    def search_unreviewed_list(self, page):
        result = self.__news_dao.search_unreivewd_list(page)
        return result

    # 查詢待審核新聞列表頁數
    def search_unreviewed_count_page(self):
        count_page = self.__news_dao.search_unreviewed_count_page()
        return count_page

    # 審核新聞 -> 將'待審核' 字段 改為 '已審核'
    def update_unreviewed_news(self, id):
        self.__news_dao.update_unreviewed_news(id)

    # 查詢新聞列表
    def search_list(self, page):
        result = self.__news_dao.search_list(page)
        return result

    # 查詢新聞總頁數
    def search_count_page(self):
        count_page = self.__news_dao.search_count_page()
        return count_page

    # 刪除新聞
    def delete_by_id(self, id):
        self.__news_dao.delete_by_id(id)