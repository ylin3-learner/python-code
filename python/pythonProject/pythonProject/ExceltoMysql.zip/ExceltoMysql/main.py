# coding:utf-8
import os
import time
import sys
from utils.db import Mysql
from utils.excel import HandleExcel

# 整合數據庫與excel操作, 負責管用戶看到的畫面
# 為何還需要另外寫一對象繼承? 使後方系統邏輯庫較好調用
class Main(object):
    def __init__(self, table_name, excel_path):
        self.table_name = table_name
        self.handle_excel = HandleExcel(excel_path)
        self.db = Mysql()

    def save_data(self):
        res = self.handle_excel.ReadExcel()  # 獲取所有學生資料
        print('\t正在導入學生信息', end='')

        # 導入前清空表中的信息
        self.db.delete_all(self.table_name)

        for stu_k, stu_v in res.items():
            self.db.insert(self.table_name, stu_k, stu_v[0], stu_v[1], stu_v[2], stu_v[3], stu_v[4])
            # 显示输出效果 "正在导入学生成绩 ..........."
            print(".", end="")
        # 顯示輸出效果
        print('\n\t導入完成')

    # 查询学生成绩
    # 如果指定学生姓名，则查询指定学生成绩，否则查询所有学生成绩
    # 必須讓username預設值為空, 否則無法成功返回所有資料
    def search_user_score(self, username=''):
        result = self.db.search_student(self.table_name, username)  # 返回列表
        if len(result) == 0:
            print('\n\t輸入錯誤, 學生不存在')
        for r in result:
            print('\n\t學號：{}'.format(r[0]))
            print('\n\t姓名：{}'.format(r[1]))
            print('\n\t語文：{}\t英文：{}\t數學：{}'.format(r[2], r[3], r[4]))
            print('\n\t總分：{}'.format(r[2]+r[3]+r[4]))
            print('\t===================================')

    def total_score_sort(self, table_name):
        res = self.db.total_score_sort(table_name)  # 列表
        for index in range(len(res)):
            one = res[index]
            print('\n第%s名\t學號：%s\t姓名：%s\t總分：%s'% (index+1, one[0], one[1], one[2]))

    def delete_all(self, table_name):
        print('您正在退出系統(3秒後退出)')
        Mysql().delete_all(table_name)
        print('請注意, 您退出後, 將自動刪除資料...')


if __name__ == '__main__':
    # table_name = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'stuinfo.sql')
    # 在实例化Main对象时，传入的第一参数是表名，第二个参数是导入文件的
    handle = Main('three_three', 'script/students.xlsx')


while True:
    page = ['退出系統', '一鍵導入學生成績信息', '查詢學生信息', '班級總成績排名']
    print('\t學生信息管理系統\t')
    print('=========功能菜單=============')
    for index in range(len(page)):
        print('%s %s' % (index, page[index]))
    print('=============================')
    print('說明：輸入數字選擇菜單')
    opt = input('請選擇：')

    if opt == '1':  # 一键导入学生成绩信息
        os.system('cls')
        print('\t\t一鍵導入, 原班級成績會被覆蓋')
        choice = input('是否繼續導入?(y/n)：')
        if choice == 'y':
            handle.save_data()
            print('導入完成(3秒後自動返回)')
            time.sleep(3)
            continue
        elif choice == 'n':
            print('\t\t您選擇,暫不導入(3秒後自動返回)')
            time.sleep(3)
            continue
    elif opt == '2':  # 查询学生成绩
        os.system('cls')
        print('輸入back返回上一層')
        username = input('查詢學生成績, 請輸入學生姓名, 不輸入將查詢所有學生成績：')
        if username != '':
            handle.search_user_score(username)
        elif username == '':
            handle.search_user_score()
        elif username == 'back':
            break
    elif opt == '3':  # 班级总成绩排名
        os.system('cls')
        res = handle.total_score_sort(table_name=handle.table_name)
        print(res)
    elif opt == '0':  # 退出系统
        os.system('cls')
        print('您已退出學生信息管理系統')
        handle.delete_all(table_name=handle.table_name)
        time.sleep(3)
        sys.exit(0)
    else:
        print("\t\t输入有误，请重新输入(2秒後自動返回)")
        time.sleep(2)