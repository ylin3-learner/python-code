# coding:utf-8

import mysql.connector.pooling


class Mysql(object):
    def __init__(self):
        self.config = {
            'host': 'localhost',
            'port': 3306,
            'user': 'root',
            'password': 'tony1120',
            'database': 'stuinfo',
            'auth_plugin': 'mysql_native_password'
        }

        self.pool = self.get_pool()
    def get_pool(self):
        try:
            pool = mysql.connector.pooling.MySQLConnectionPool(
                **self.config,
                pool_size=10
            )
        except Exception as e:
            raise e
        return pool

    def insert(self, table_name, stu_no, username, gender, Chinese_score, English_score, Math_score):
        try:
            con = self.pool.get_connection()
            con.start_transaction()
            cursor = con.cursor()
            # 判斷如果存在, 就更新資料; 如果不存在, 插入資料
            # sql语句中以参数的方式传入表名时，表名是有引号的，在执行sql时会报错，
            # 其他功能在涉及到传入表名的sql语句时，都需使用字符串拼接实现完整sql语句
            sql = 'INSERT INTO ' + table_name +\
                  '(stu_no, username, gender, Chinese_score, Math_score, English_score) '\
                  'VALUES(%s, %s, %s, %s, %s, %s)'
            cursor.execute(sql, (stu_no, username, gender, Chinese_score, English_score, Math_score))
            con.commit()
        except Exception as e:
            if 'con' in dir():
                print(e)
                con.rollback()
        finally:
            if 'con' in dir():
                con.close()

    def search_student(self, table_name, username=''):  # 可以為空, 如果為空, 則查所有信息
        try:
            con = self.pool.get_connection()
            cursor = con.cursor()
            sql = 'SELECT stu_no, username, Chinese_score, English_score, Math_score ' \
                  'FROM ' + table_name
            if username != '':
                sql += ' WHERE username = %s'
                cursor.execute(sql, (username,))
            else:
                cursor.execute(sql)
            student_info = cursor.fetchall()
            return student_info
        except Exception as e:
            if 'con' in dir():
                print(e)
                con.rollback()
        finally:
            if 'con' in dir():
                con.close()

    def delete_all(self, table_name):
        try:
            con = self.pool.get_connection()
            cursor = con.cursor()
            sql = 'TRUNCATE table '+ table_name  # 涉及刪除語句, 提示信息
            cursor.execute(sql)
            con.commit()
        except Exception as e:
            if 'con' in dir():
                print(e)
                con.rollback()
        finally:
            if 'con' in dir():
                con.close()

    # 总成绩排名
    def total_score_sort(self, table_name):
        try:
            con = self.pool.get_connection()
            cursor = con.cursor()
            # coalesce(chinese,0)+coalesce(english,0)+ coalesce(math,0)
            # 備註 如果那三個欄位可為空
            # 建議使用 coalesce(chinese,0)+coalesce(english,0)+ coalesce(math,0)
            # 不然只要有一個欄是空值 計算結果就是空值
            sql = 'SELECT stu_no, username, (Chinese_score+English_score+Math_score) AS total FROM '\
                  + table_name +\
                  ' ORDER BY total DESC'
            cursor.execute(sql)
            student_info = cursor.fetchall()
            return student_info
        except Exception as e:
            if 'con' in dir():
                print(e)
                con.rollback()
        finally:
            if 'con' in dir():
                con.close()


