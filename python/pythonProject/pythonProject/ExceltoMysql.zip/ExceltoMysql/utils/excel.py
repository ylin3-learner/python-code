# coding:utf-8

import xlrd  # 讀excel的module

class HandleExcel(object):
    def __init__(self, filename):
        self.filename = filename  # 初始化傳參

    # 读取Excel表中的学生成绩
    # 以字典形式返回学生成绩，学号为字典的key，其余内容为字典的value
    # 格式：{20213301: ['慕桂英', '女', 99.0, 100.0, 96.0], 20213302: ['dewei', '男', 98.0, 95.0, 97.5], ...}
    def ReadExcel(self):
        excel = xlrd.open_workbook(self.filename)  # 創建excel object

        book = excel.sheet_by_index(0)
        # 將所有數據放入字典內
        stu_dict = {}
        for row_num in range(1, book.nrows):  # 從第一列 到 最後一列
            k = int(book.row_values(row_num)[0])  # key
            stu_dict[k] = book.row_values(row_num)[1:]  # value

        return stu_dict

if __name__ == "__main__":
    d = HandleExcel("../script/students.xlsx")
    res = d.ReadExcel()
    print(res)